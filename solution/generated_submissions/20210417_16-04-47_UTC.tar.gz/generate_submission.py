import configparser
import pathlib as path

import numpy as np
import pandas as pd
import joblib

from functions.aux_functions import prepare_data

def main(cfg):
    # parse config
    DATA_FOLDER = path.Path(cfg["DATA"]["DatasetPath"])
    USER_ID = cfg["COLUMNS"]["USER_ID"]
    PREDICTION = cfg["COLUMNS"]["PREDICTION"]
    MODEL_PATH = path.Path(cfg["MODEL"]["FilePath"])
    SUBMISSION_FILE = path.Path(cfg["SUBMISSION"]["FilePath"])
    
    # prepare data
    prepare_data(cfg["DATA"]["DatasetPath"])
    
    test_data = pd.read_csv(f'{DATA_FOLDER}/{cfg["DATA"]["UsersFile"]}')
    if 'sale_flg' in list(test_data.columns):
        test_data = test_data.drop(columns=['sale_flg'])
    model = joblib.load(MODEL_PATH)
    
    submission = test_data[[USER_ID]].copy()
    # submission[PREDICTION] = np.random.choice([0, 1], len(submission))
    submission[PREDICTION] = model.predict(test_data)
    submission.to_csv(SUBMISSION_FILE, index=False)


if __name__ == "__main__":
    config = configparser.ConfigParser()
    config.read("./config.ini")
    main(cfg=config)
