import pandas as pd
import numpy as np

def prepare_data_baseline(data_folder):
    
    if data_folder[-1] != '/':
        data_folder = data_folder + '/'
    
    # load csv data files
    df_funnel = pd.read_csv(data_folder + 'funnel.csv')
    df_client = pd.read_csv(data_folder + 'client.csv')
    
#     if 'sale_flg' in list(df_funnel.columns):
#         df_comb_feat = df_funnel[['sale_flg', 'feature_1', 'feature_2', 'feature_3', 'feature_4', 
#                                   'feature_5', 'feature_6', 'feature_7', 'feature_8', 'feature_9']]
# #         df_comb_feat = df_funnel[['client_id', 'feature_1', 'feature_2', 'feature_3', 'feature_4', 
# #                                   'feature_5', 'feature_6', 'feature_7', 'feature_8', 'feature_9']]
#     else:
#          df_comb_feat = df_funnel[['client_id', 'feature_1', 'feature_2', 'feature_3', 'feature_4', 
#                                   'feature_5', 'feature_6', 'feature_7', 'feature_8', 'feature_9']]
        


    # merge by client_id
    df_comb_feat = pd.merge(df_funnel, df_client, on='client_id')
    
    # drop columns with str vals
    df_comb_feat = df_comb_feat.drop(columns=['gender', 'citizenship', 'education', 'job_type'])
    
    # if train data, drop columns that aren't available in test data except for 'sale_flg'
    if 'sale_flg' in list(df_comb_feat.columns):
        df_comb_feat = df_comb_feat.drop(columns=['client_id', 'sale_amount', 'contacts'])
#         df_comb_feat = df_comb_feat.drop(columns=['sale_flg', 'sale_amount', 'contacts'])
    
    return df_comb_feat

def prepare_data(data_folder):
    
    if data_folder[-1] != '/':
        data_folder = data_folder + '/'
    
    # load csv data files
    df_funnel = pd.read_csv(data_folder + 'funnel.csv')
    df_client = pd.read_csv(data_folder + 'client.csv')
    
    # add education_bool feature
    df_client["education_bool"] = (df_client["education"] == 'PRIMARY_PROFESSIONAL') | (pd.isna(df_client["education"]))
    df_client["education_bool"] = 1 - df_client["education_bool"]
    
    
    
    # add regional features
    # good
    good_regions = [0, 4, 10, 50, 71]    
    df_client["region_good_bool"] = (df_client["region"] == 'dummy_val')
    for i, reg in enumerate(good_regions):
        df_client["region_good_bool"] = df_client["region_good_bool"] | (df_client["region"] == reg)
    
    # bad    
    bad_regions = [46, 57, 60, 72, 76]   
    df_client["region_bad_bool"] = (df_client["region"] == 'dummy_val')
    for i, reg in enumerate(bad_regions):
        df_client["region_bad_bool"] = df_client["region_bad_bool"] | (df_client["region"] == reg)
    
    
    
    # add city-related features
    # good
    good_cities = [2,8,12,63,66,69,75,103,136,140,166,172,280,337,375,386,412,416,425]
    df_client["city_good_bool"] = (df_client["city"] == 'dummy_val')
    for i, cit in enumerate(good_cities):
        df_client["city_good_bool"] = df_client["city_good_bool"] | (df_client["city"] == cit)
    
    # bad
    bad_cities = [70, 122, 228, 308, 363, 481, 508, 543, 801, 1173]
    df_client["city_bad_bool"] = (df_client["city"] == 'dummy_val')
    for i, cit in enumerate(bad_cities):
        df_client["city_bad_bool"] = df_client["city_bad_bool"] | (df_client["city"] == cit)
    
    
    # merge by client_id
    df_comb_feat = pd.merge(df_funnel, df_client, on='client_id')
    
    # drop columns with str vals
#     df_comb_feat = df_comb_feat.drop(columns=['gender', 'citizenship', 'education', 'job_type'])
    df_comb_feat = df_comb_feat.drop(columns=['city', 'region', 'gender', 'citizenship', 'education', 'job_type'])
    
    # if train data, drop columns that aren't available in test data except for 'sale_flg'
    if 'sale_flg' in list(df_comb_feat.columns):
        df_comb_feat = df_comb_feat.drop(columns=['client_id', 'sale_amount', 'contacts'])
#         df_comb_feat = df_comb_feat.drop(columns=['sale_flg', 'sale_amount', 'contacts'])
    print(df_comb_feat.columns)
    
    return df_comb_feat

