import pandas as pd

def prepare_data(data_folder):
    
    if data_folder[-1] != '/':
        data_folder = data_folder + '/'
    
    # load csv data files
    df_funnel = pd.read_csv(data_folder + 'funnel.csv')
    #df_client = pd.read_csv(data_folder + 'client.csv')
    
    if 'sale_flg' in list(df_funnel.columns):
        df_comb_feat = df_funnel[['client_id', 'feature_1', 'sale_flg']]
    else:
        df_comb_feat = df_funnel[['client_id', 'feature_1']]
    
#     # merge by client_id
#     df_comb_feat = pd.merge(df_funnel, df_client, on='client_id')
    
#     # drop columns with str vals
#     df_comb_feat = df_comb_feat.drop(columns=['gender', 'citizenship', 'education', 'job_type'])
    
#     # if train data, drop columns that aren't available in test data except for 'sale_flg'
#     if 'sale_flg' in list(df_comb_feat.columns):
#         df_comb_feat = df_comb_feat.drop(columns=['client_id', 'sale_amount', 'contacts'])
    
    # save data in the data folder
    df_comb_feat.to_csv(data_folder + 'combined_features.csv', index=False)