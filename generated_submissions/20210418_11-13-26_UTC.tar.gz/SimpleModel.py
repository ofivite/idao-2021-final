from sklearn.linear_model import LogisticRegression
import lightgbm as lgb
import numpy as np 
from sklearn.model_selection import train_test_split

class SimpleModel():
    def __init__(self):
        self.model = LogisticRegression()

    def fit(self, X, y):
        self.features = [c for c in X]
        self.model.fit(X, y)

    def predict(self, X):
        X_test = X[self.features]
        y_pred = self.model.predict(X_test)
        return y_pred
    
class BoostingModel():
    def __init__(self):
        self.model = lgb
        self.params = {
            'boosting_type': 'gbdt',
            'objective': 'binary',
            'metric': 'binary_logloss',
            'max_depth': 4,
            'learning_rate': 0.1,
            'feature_fraction': 0.9,
            'bagging_fraction': 0.8,
            'bagging_freq': 5,
            'seed': 777,
#             'early_stopping': 10,
            'verbose': -1
        }

    def fit(self, X, y):
        
#         X_train, X_test, y_train, y_test = train_test_split(X.values, y.values, test_size=0.33, random_state=42)
        
# #         n_samples = len(y_train)
#         #w_per_cl = n_samples/(2*np.bincount(y_train))
#         #w = [w_per_cl[0] if y_train[i]==0 else w_per_cl[1] for i in range(len(y_train))]
        
#         lgb_train = self.model.Dataset(X_train, y_train, free_raw_data=False)#, weight=w)
#         lgb_eval = self.model.Dataset(X_test, y_test, reference=lgb_train, free_raw_data=False)

#         self.model = self.model.train(
#                 self.params,
#                 lgb_train,
#                 valid_sets=lgb_eval,
#                 num_boost_round=1000
#                )

        
        n_samples = len(y)
        w_per_cl = n_samples/(2*np.bincount(y))
        w = [1 if y.iloc[i]==0 else 100 for i in range(len(y.values))]
#         w = [0 for i in range(len(y.values))]
#         w = [1 if y[i]==0 ]     
        lgb_train = self.model.Dataset(X, y, free_raw_data=False, weight=w)

        self.model = self.model.train(
                self.params,
                lgb_train,
                num_boost_round=1000
               )
        
    def predict(self, X):
        y_pred = np.array(np.round(self.model.predict(X)), dtype=int)
#         y_pred = self.model.predict(X) > 0.5
        return y_pred
