import configparser
import pathlib as path
import logging

import numpy as np
import pandas as pd
import joblib

from functions.aux_functions import prepare_data

from SimpleModel import SimpleModel, BoostingModel


logging.basicConfig(format='%(asctime)s %(message)s', filename='training.log', level=logging.DEBUG)


def main(cfg):
    # parse config
    DATA_FOLDER = path.Path(cfg["DATA"]["DatasetPath"])
    MODEL_PATH = path.Path(cfg["MODEL"]["FilePath"])
    
    # combine funnel and client features, drop columns that aren't available in test
    train_data = prepare_data(cfg["DATA"]["DatasetPath"])
    
    # get data
    #train_data = pd.read_csv(f'{DATA_FOLDER}/{cfg["DATA"]["UsersFile"]}')
    X = train_data.drop(columns=['sale_flg'])
    y = train_data['sale_flg']
    
    # fit the model
    model = BoostingModel()
#     model.fit(X, y)
    model.fit(X, y)
    joblib.dump(model, MODEL_PATH)
    logging.info("model was trained")
    
    submission = pd.Series(model.predict(X))   
    submission.to_csv('train_predict.csv', index=False)
    y_true = pd.Series(y)   
    y_true.to_csv('true_train.csv', index=False)
    
if __name__ == "__main__":
    config = configparser.ConfigParser()
    config.read("./config.ini")
    main(cfg=config)
