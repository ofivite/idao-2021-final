from sklearn.linear_model import LogisticRegression
import lightgbm as lgb
import numpy as np 

class SimpleModel():
    def __init__(self):
        self.model = LogisticRegression()

    def fit(self, X, y):
        self.features = [c for c in X]
        self.model.fit(X, y)

    def predict(self, X):
        X_test = X[self.features]
        y_pred = self.model.predict(X_test)
        return y_pred
    
class BoostingModel():
    def __init__(self):
        self.model = lgb
        self.params = {
            'boosting_type': 'gbdt',
            'objective': 'binary',
            'metric': 'binary_logloss',
            'max_depth': 4,
            'learning_rate': 0.1,
            'feature_fraction': 0.9,
            'bagging_fraction': 0.8,
            'bagging_freq': 5,
            'seed': 777,
            'verbose': -1
        }

    def fit(self, X, y):
        n_samples = len(y)
        w_per_cl = n_samples/(2*np.bincount(y))
#         w = [w_per_cl[0] if y[i]==0 else w_per_cl[1] for i in range(len(y))]
        w = [1/17000 if y[i]==0 else 1/3500 for i in range(len(y))]
        lgb_train = self.model.Dataset(X, y, free_raw_data=False, weight=w)
        self.model = self.model.train(
                self.params,
                lgb_train,
                num_boost_round=1000
               )

    def predict(self, X):
        y_pred = np.array(np.round(self.model.predict(X)), dtype=int)
        return y_pred
